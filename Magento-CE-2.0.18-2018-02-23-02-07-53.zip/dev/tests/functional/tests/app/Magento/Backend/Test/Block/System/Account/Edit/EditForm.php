<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Backend\Test\Block\System\Account\Edit;

use Magento\Mtf\Block\Form;

class EditForm extends Form
{
    //
}
